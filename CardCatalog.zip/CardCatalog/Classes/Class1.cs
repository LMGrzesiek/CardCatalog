﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ClassLibrary
{
    public class CardCatalog
    {
        private string string_filename;

        private List<Book> books;

        public CardCatalog(string fileName)
        {
            string path = @"C:\" + fileName + ".txt";
            File.Create(path);
            
        }

        public List<Book> ListBooks()
        {
            return books;
        }

        public void AddBook()
        {
            Console.WriteLine("Provide a title: ");
            string title = Console.ReadLine();

            Console.WriteLine("Provide the author: ");
            string author = Console.ReadLine();

            Console.WriteLine("Provide the genre: ");
            string genre = Console.ReadLine();

            Book book = new Book
            {
                Title = title,
                Author = author,
                Genre = genre
            };

            books.Add(book);
        }

        public void Save()
        {
            

            
        }


    }

    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }

        //public Book(string title, string author, string genre)
        //{
        //    Title = title;
        //    Author = author;
        //    Genre = genre;
        //}

        //public override string ToString()
        //{
        //    return String.Format("Title : {0}\nAuthor : {1}\nGenre : {2}", Title, Author, Genre);
        //}
     }
}
