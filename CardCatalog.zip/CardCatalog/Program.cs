﻿using System;

namespace CardCatalog
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What one-word name would you like to call your card catalog?");
            string fileName = Console.ReadLine();
            bool hasSpace = fileName.Contains(" ");

            if (hasSpace == true)
            {
                Console.WriteLine("I'm sorry, your name fails to meet the one-word requirement, please try again...");
                Console.WriteLine("What one-word name would you like to call your card catalog?");
            }
            else
            {
                Console.WriteLine("Thank you! Please choose an option from the menu below:");
            }

            string userChoice = MainMenu();

            if (result == "1")
            {
                ListBooks();
                return true;
            }
            else if (result == "2")
            {
                AddBook();
                return true;
            }
            else if (result == "3")
            {
                return false;
            }
            else
            {
                return true;
            }



        }

        //public void Propmt()  **Like to create a simple method that calls the initial prompt for a file name
        //{
        //    Console.WriteLine("What one-word name would you like to call your card catalog?");

        //}

        private static string MainMenu()
        {
            //Console.Clear();  Do we need this option?
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1) List All Books");
            Console.WriteLine("2) Add A Book");
            Console.WriteLine("3) Save and Exit");
            return Console.ReadLine();
            


            
        }
    }
}
